// certificateService.js

import axios from 'axios';

const API_URL = 'http://localhost:5000/api/certificates';

export const addCertificate = async (certificateData) => {
  try {
    const token = localStorage.getItem('token');
    const response = await axios.post(`${API_URL}/add`, certificateData, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Failed to add certificate.' };
  }
};

export const verifyCertificate = async (email) => {
  try {
    const response = await axios.post(`${API_URL}/verify`, { email });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Verification failed.');
  }
};

export const getCertificatesByEmail = async (email) => {
  try {
    const token = localStorage.getItem('token');
    const response = await axios.get(`${API_URL}/user/${email}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching certificates:", error.response.data);
    throw error.response?.data || { message: 'Failed to fetch certificates.' };
  }
};
