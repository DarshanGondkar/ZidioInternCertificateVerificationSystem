// App.js

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './pages/Header';
import Footer from './pages/Footer';
import MainPage from './pages/MainPage';
import RegisterPage from './pages/RegisterPage';
import LoginPage from './pages/LoginPage';
import UserDashboard from './pages/UserDashboard';
import AdminDashboard from './pages/AdminDashboard';
import ProtectedRoute from './ProtectedRoute';
import '@fortawesome/fontawesome-free/css/all.min.css';
import './index.css'; 

/* name: Darshan Gondkar*/

const App = () => {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/LoginPage" element={<LoginPage />} />
        <Route path="/RegisterPage" element={<RegisterPage />} />
        
        {/* Protected Routes */}
        <Route 
          path="/AdminDashboard" 
          element={
            <ProtectedRoute requiredRole="admin" element={<AdminDashboard />} />
          } 
        />
        <Route 
          path="/UserDashboard" 
          element={
            <ProtectedRoute requiredRole="user" element={<UserDashboard />} />
          } 
        />
      </Routes>
      <Footer />
    </Router>
  );
};

export default App;
