import React, { useState, useEffect } from 'react';
import { verifyCertificate } from '../services/certificateService';
import { useNavigate } from 'react-router-dom';
import { jsPDF } from 'jspdf';

const UserDashboard = () => {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [certificate, setCertificate] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/LoginPage'); // Redirect if no token is found
    }
  }, [navigate]);

  const handleVerify = async () => {
    setMessage(''); // Clear previous messages
    setCertificate(null); // Clear previous certificate details
    try {
      const result = await verifyCertificate(email); // Call the service to verify the certificate based on the email

      if (result?.valid && result.certificate) {
        setCertificate(result.certificate); // Set the certificate to state if valid
        setMessage('Certificate verified successfully!');
      } else {
        setMessage('No certificate found for this email.');
      }
    } catch (error) {
      console.error('Error during verification:', error);
      setMessage('An error occurred during verification.'); // Handle errors gracefully
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token'); // Remove token from localStorage
    navigate('/LoginPage'); // Redirect to login page
  };

  const handleDownload = () => {
    if (!certificate) return;

    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text('Certificate of Completion', 20, 20);
    doc.setFontSize(12);
    doc.text(`Certificate ID: ${certificate.certificateId}`, 20, 40);
    doc.text(`Course Name: ${certificate.courseName}`, 20, 50);
    doc.text(`Issued Date: ${new Date(certificate.issuedDate).toLocaleDateString()}`, 20, 60);
    doc.text(`Expiry Date: ${new Date(certificate.expiryDate).toLocaleDateString()}`, 20, 70);
    doc.text(`Issued to: ${certificate.studentName}`, 20, 80);
    doc.text(`Issuer: ${certificate.issuer}`, 20, 90); // Added issuer

    doc.save(`Certificate_${certificate.certificateId}.pdf`);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center">
      <div className="w-full max-w-2xl p-8 bg-white shadow-2xl rounded-lg border-t-4 border-blue-600">
        <h2 className="text-3xl font-bold text-center mb-6">Certificate Verification</h2>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          className="w-full mb-4 p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
          required
        />
        <button
          onClick={handleVerify}
          className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition duration-300 mb-4"
        >
          Verify
        </button>
        {message && <p className="mt-4 text-gray-700 text-center">{message}</p>}
        {certificate && (
          <div className="mt-6 bg-white p-6 rounded-lg shadow-lg border border-gray-200">
            <h3 className="text-2xl font-semibold mb-4 text-center text-blue-700">Certificate</h3>
            <div className="text-gray-800 text-lg">
              <p><strong>Course Name:</strong> {certificate.courseName}</p>
              <p><strong>Issued Date:</strong> {new Date(certificate.issuedDate).toLocaleDateString()}</p>
              <p><strong>Expiry Date:</strong> {new Date(certificate.expiryDate).toLocaleDateString()}</p>
              <p><strong>Certificate ID:</strong> {certificate.certificateId}</p>
              <p><strong>Name of Student:</strong> {certificate.studentName}</p> {/* Added student name */}
              <p><strong>Issuer:</strong> {certificate.issuer}</p> {/* Added issuer */}
            </div>
            <button
              onClick={handleDownload}
              className="w-full mt-6 bg-green-500 text-white py-2 rounded-lg font-semibold hover:bg-green-600 transition duration-300"
            >
              Download Certificate
            </button>
          </div>
        )}
        <button
          onClick={handleLogout}
          className="w-full mt-6 bg-red-500 text-white py-3 rounded-lg font-semibold hover:bg-red-600 transition duration-300"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default UserDashboard;
