import React, { useState } from 'react';
import { verifyCertificate } from '../services/certificateService';

const VerifyCertificate = () => {
  const [certificateId, setCertificateId] = useState('');
  const [verificationResult, setVerificationResult] = useState(null);

  const handleVerify = async () => {
    try {
      const result = await verifyCertificate(certificateId);
      setVerificationResult(result);
    } catch (error) {
      console.error('Verification failed:', error);
    }
  };

  return (
    <div>
      <h2>Verify Certificate</h2>
      <input
        type="text"
        value={certificateId}
        onChange={(e) => setCertificateId(e.target.value)}
        placeholder="Enter Certificate ID"
      />
      <button onClick={handleVerify}>Verify</button>
      {verificationResult && (
        <div>
          {verificationResult.valid ? (
            <p>Certificate is valid.</p>
          ) : (
            <p>Certificate is not valid.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default VerifyCertificate;
