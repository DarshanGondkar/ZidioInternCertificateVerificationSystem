/*// ProtectedRoute.js

import React from 'react';
import { Navigate } from 'react-router-dom';
import {jwtDecode} from 'jwt-decode'; // Ensure you're using this package

const ProtectedRoute = ({ element, requiredRole }) => {
  const token = localStorage.getItem('token');
  let userRole = null;

  // Decode the token to extract the role if the token exists
  if (token) {
    try {
      const decodedToken = jwtDecode(token);
      userRole = decodedToken.role; // Ensure the token has the 'role' property
    } catch (error) {
      console.error('Token decoding error:', error);
    }
  }

  // Check if token is present and user role matches the required role
  if (!token || userRole !== requiredRole) {
    return <Navigate to="/LoginPage" />; // Redirect to login if not authenticated
  }

  return element; // Render the protected component
};

export default ProtectedRoute;
*/