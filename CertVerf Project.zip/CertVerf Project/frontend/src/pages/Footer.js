import React from 'react';

const Footer = () => (
  <footer className="bg-gray-900 text-white py-4">
    <div className="container mx-auto flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0 px-4">
      {/* Left Section: Branding */}
      <div className="text-center md:text-left">
        <h2 className="text-lg font-semibold">certCrypt</h2>
        <p className="text-gray-400">© 2024 All Rights Reserved</p>
      </div>

      {/* Center Section: Navigation Links */}
      <div className="flex space-x-4 text-gray-400">
  <a href="#about" className="hover:text-white">About</a>
  <a href="https://www.google.com/maps/place/Your+Location+Name" target="_blank" rel="noopener noreferrer" className="hover:text-white">Location</a>
  <a href="mailto:darshangondkar2018@gmail.com" className="hover:text-white">Mail us</a>
</div>


      {/* Right Section: Social Media Icons */}
      <div className="flex space-x-4">
        <a href="https://twitter.com" aria-label="Twitter" className="text-gray-400 hover:text-white">
          <i className="fab fa-twitter"></i>
        </a>
        <a href="https://facebook.com" aria-label="Facebook" className="text-gray-400 hover:text-white">
          <i className="fab fa-facebook-f"></i>
        </a>
        <a href="https://linkedin.com" aria-label="LinkedIn" className="text-gray-400 hover:text-white">
          <i className="fab fa-linkedin-in"></i>
        </a>
      </div>
    </div>
  </footer>
);

export default Footer;
