// LoginPage.js

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login } from '../services/authService'; // Adjust this import path as needed

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); // Clear any previous error messages
    try {
      const { token, role } = await login({ email, password });
      
      // Check if the token is valid and received
      if (token) {
        localStorage.setItem('token', token);
        localStorage.setItem('role', role);
        
        // Navigate based on user role
        if (role === 'admin') {
          console.log('Redirecting to AdminDashboard'); // Debugging log
          navigate('/AdminDashboard');
        } else {
          console.log('Redirecting to UserDashboard'); // Debugging log
          navigate('/UserDashboard');
        }
      } else {
        setError('Login failed. Please try again.'); // Handle unexpected cases
      }
    } catch (err) {
      console.error('Login error:', err); // Log the error for debugging
      setError(err.message); // Show the error message from the server
    }
  };

  return (
    <div className="flex h-screen">
      <div className="w-1/2 bg-black text-white flex items-center justify-center">
        <h1 className="text-5xl font-bold">certCrypt</h1>
      </div>
      <div className="w-1/2 flex items-center justify-center bg-white">
        <div className="w-3/4 max-w-md p-8 shadow-lg rounded-lg">
          <h2 className="text-3xl font-bold mb-4">Welcome back!</h2>
          <p className="mb-6 text-gray-600">Please enter your details</p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-lg font-semibold mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                placeholder="Enter your email"
                required
              />
            </div>
            <div>
              <label className="block text-lg font-semibold mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                placeholder="Enter your password"
                required
              />
            </div>
            <button type="submit" className="w-full bg-black text-white py-2 rounded-lg font-semibold">
              Sign in
            </button>
          </form>
          {error && <p className="text-red-500 mt-4">{error}</p>}
          <p className="mt-6 text-center">
            Don't have an account?{' '}
            <a href="/RegisterPage" className="text-black font-bold">Sign up</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
