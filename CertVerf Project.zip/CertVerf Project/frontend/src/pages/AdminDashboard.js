import React, { useState } from 'react';
import { addCertificate } from '../services/certificateService';
import { useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const [certificateData, setCertificateData] = useState({
    certificateId: '',
    userEmail: '',
    courseName: '',
    issuedDate: '',
    expiryDate: '',
    studentName: '', // Added student name
    issuer: '' // Added issuer
  });
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/LoginPage');
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCertificateData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(certificateData.userEmail)) {
        setError('Invalid email format. Please enter a valid email address.');
        return;
      }

      const uniqueCertificateId = `cert-${Date.now()}`;

      await addCertificate({
        ...certificateData,
        certificateId: uniqueCertificateId
      });

      setSuccessMessage('Certificate added successfully!');
      setCertificateData({
        certificateId: '',
        userEmail: '',
        courseName: '',
        issuedDate: '',
        expiryDate: '',
        studentName: '', // Reset student name
        issuer: '' // Reset issuer
      });
      setError('');
    } catch (err) {
      setError('Failed to add certificate. Please try again.');
      console.error('Error details:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="w-full max-w-2xl p-8 bg-white shadow-lg rounded-lg border border-gray-300">
        <h2 className="text-3xl font-bold mb-6 text-center">Admin Dashboard</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-lg font-semibold mb-2">User Email</label>
            <input
              type="email"
              name="userEmail"
              value={certificateData.userEmail}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
              placeholder="Enter user email"
              required
            />
          </div>
          <div>
            <label className="block text-lg font-semibold mb-2">Course Name</label>
            <input
              type="text"
              name="courseName"
              value={certificateData.courseName}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
              placeholder="Enter course name"
              required
            />
          </div>
          <div>
            <label className="block text-lg font-semibold mb-2">Issued Date</label>
            <input
              type="date"
              name="issuedDate"
              value={certificateData.issuedDate}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-lg font-semibold mb-2">Expiry Date</label>
            <input
              type="date"
              name="expiryDate"
              value={certificateData.expiryDate}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-lg font-semibold mb-2">Name of Student</label>
            <input
              type="text"
              name="studentName"
              value={certificateData.studentName} // Controlled input for student name
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
              placeholder="Enter name of student"
              required
            />
          </div>
          <div>
            <label className="block text-lg font-semibold mb-2">Certificate Issuer</label>
            <input
              type="text"
              name="issuer"
              value={certificateData.issuer} // Controlled input for issuer
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
              placeholder="Enter issuer's name"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition duration-300"
          >
            Add Certificate
          </button>
          {successMessage && <p className="text-green-500 text-center">{successMessage}</p>}
          {error && <p className="text-red-500 text-center">{error}</p>}
        </form>
        <button
          onClick={handleLogout}
          className="w-full mt-6 bg-red-500 text-white py-3 rounded-lg font-semibold hover:bg-red-600 transition duration-300"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default AdminDashboard;
