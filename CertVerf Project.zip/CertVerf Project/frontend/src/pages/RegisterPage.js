import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { register } from '../services/authService';

const RegisterPage = () => {
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('user');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await register({ email, mobile, password, role });
      setSuccessMessage('Registration successful! Redirecting to login...');
      setTimeout(() => navigate('/LoginPage'), 2000);
    } catch (err) {
      setError(err.message || 'Registration failed. Please try again.');
    }
  };

  return (
    <div className="flex h-screen">
      <div className="w-1/2 bg-black text-white flex items-center justify-center">
        <h1 className="text-5xl font-bold">certCrypt</h1>
      </div>
      <div className="w-1/2 flex items-center justify-center bg-white">
        <div className="w-3/4 max-w-md p-8 shadow-lg rounded-lg">
          <h2 className="text-3xl font-bold mb-4">Create an account</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-lg font-semibold mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                placeholder="Enter your email"
                required
              />
            </div>
            <div>
              <label className="block text-lg font-semibold mb-2">Mobile No.</label>
              <input
                type="tel"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                placeholder="Enter your mobile number"
                required
              />
            </div>
            <div>
              <label className="block text-lg font-semibold mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                placeholder="Create a password"
                required
              />
            </div>
            <div>
              <label className="block text-lg font-semibold mb-2">Role</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              >
                <option value="user">User</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <button type="submit" className="w-full bg-black text-white py-2 rounded-lg font-semibold">
              Sign up
            </button>
          </form>
          {error && <p className="text-red-500 mt-4">{error}</p>}
          {successMessage && <p className="text-green-500 mt-4">{successMessage}</p>}
          <p className="mt-6 text-center">
            Already have an account?{' '}
            <a href="/LoginPage" className="text-black font-bold">Sign in</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
