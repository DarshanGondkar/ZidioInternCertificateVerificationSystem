{/*}import React from 'react';

const Footer = () => <footer>© 2024 Certificate Verification System</footer>;

export default Footer;
{*/}
